<div class="footer-logo">
    <a href="#"><img src='<?= base_url('images/bottom_logo.jpg'); ?>' width="946" height="86"></a>
</div>
<div class="footer-text">
    <p>TBSU/HELVETAS Swiss Intercooperation Nepal © 2022</p>
    <p>For technical problems and feedbacks please email to System Officer: akaram.salamani@helvetas.org </p>
    <p class="visible-xs visible-sm">Not supported in mobile devices.</p>
</div>