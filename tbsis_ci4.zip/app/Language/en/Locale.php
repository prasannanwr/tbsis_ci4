<?php
return [
    'index_action_th' => 'Actions'
];